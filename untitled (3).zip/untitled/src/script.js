// Pequena animação ao carregar a página

document.addEventListener("DOMContentLoaded", () => {

  const cards = document.querySelectorAll(".service");

  cards.forEach((card, index) => {
    card.style.opacity = "0";
    card.style.transform = "translateY(20px)";

    setTimeout(() => {
      card.style.transition = "0.5s";
      card.style.opacity = "1";
      card.style.transform = "translateY(0)";
    }, 150 * index);
  });

});