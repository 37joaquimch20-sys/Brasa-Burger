// ==========================================
// BRASA BURGER - SCRIPT COMPLETO
// ==========================================


// CARRINHO
let carrinho = [];


// ==========================================
// ADICIONAR PRODUTO
// ==========================================

function adicionarCarrinho(nome, preco) {

    const produtoExistente = carrinho.find(
        item => item.nome === nome
    );

    if (produtoExistente) {

        produtoExistente.quantidade++;

    } else {

        carrinho.push({
            nome: nome,
            preco: preco,
            quantidade: 1
        });

    }

    atualizarCarrinho();
}


// ==========================================
// AUMENTAR QUANTIDADE
// ==========================================

function aumentarQuantidade(index) {

    if (!carrinho[index]) {
        return;
    }

    carrinho[index].quantidade++;

    atualizarCarrinho();
}


// ==========================================
// DIMINUIR QUANTIDADE
// ==========================================

function diminuirQuantidade(index) {

    if (!carrinho[index]) {
        return;
    }

    carrinho[index].quantidade--;

    if (carrinho[index].quantidade <= 0) {

        carrinho.splice(index, 1);

    }

    atualizarCarrinho();
}


// ==========================================
// REMOVER PRODUTO
// ==========================================

function removerProduto(index) {

    if (!carrinho[index]) {
        return;
    }

    carrinho.splice(index, 1);

    atualizarCarrinho();
}


// ==========================================
// ATUALIZAR CARRINHO
// ==========================================

function atualizarCarrinho() {

    const lista = document.getElementById("lista-carrinho");
    const totalElemento = document.getElementById("total");

    if (!lista || !totalElemento) {
        return;
    }

    lista.innerHTML = "";

    if (carrinho.length === 0) {

        lista.innerHTML =
            '<p style="color:#aaa;">Seu carrinho está vazio.</p>';

        totalElemento.innerText = "0,00";

        return;
    }

    let total = 0;


    carrinho.forEach(function(item, index) {

        const subtotal =
            item.preco * item.quantidade;

        total += subtotal;


        const div =
            document.createElement("div");

        div.className = "item-carrinho";


        div.innerHTML = `

            <div class="item-nome">

                <strong>${item.nome}</strong>

                <br>

                <small>
                    R$ ${subtotal
                        .toFixed(2)
                        .replace(".", ",")}
                </small>

            </div>


            <div class="quantidade">

                <button
                    type="button"
                    onclick="diminuirQuantidade(${index})"
                >
                    −
                </button>

                <span>
                    ${item.quantidade}
                </span>

                <button
                    type="button"
                    onclick="aumentarQuantidade(${index})"
                >
                    +
                </button>

                <button
                    type="button"
                    class="remover"
                    onclick="removerProduto(${index})"
                >
                    ×
                </button>

            </div>

        `;


        lista.appendChild(div);

    });


    totalElemento.innerText =
        total.toFixed(2).replace(".", ",");
}


// ==========================================
// TIPO DE PEDIDO
// ==========================================

function alterarTipoPedido() {

    const tipo =
        document.getElementById("tipo-pedido");

    const campoEndereco =
        document.getElementById("campo-endereco");


    if (!tipo || !campoEndereco) {
        return;
    }


    if (tipo.value === "retirada") {

        campoEndereco.style.display = "none";

    } else {

        campoEndereco.style.display = "block";

    }
}


// ==========================================
// CALCULAR TOTAL
// ==========================================

function calcularTotal() {

    let total = 0;

    carrinho.forEach(function(item) {

        total +=
            item.preco * item.quantidade;

    });

    return total;
}


// ==========================================
// FINALIZAR PEDIDO
// ==========================================

function finalizarPedido() {

    // Verifica se o carrinho está vazio

    if (carrinho.length === 0) {

        alert(
            "Seu carrinho está vazio. Adicione algum produto!"
        );

        return;
    }


    // Pega os dados do cliente

    const nomeElemento =
        document.getElementById("nome-cliente");

    const enderecoElemento =
        document.getElementById("endereco");

    const tipoElemento =
        document.getElementById("tipo-pedido");

    const pagamentoElemento =
        document.getElementById("pagamento");


    if (
        !nomeElemento ||
        !enderecoElemento ||
        !tipoElemento ||
        !pagamentoElemento
    ) {

        alert(
            "Erro no formulário. Verifique os campos."
        );

        return;
    }


    const nome =
        nomeElemento.value.trim();

    const endereco =
        enderecoElemento.value.trim();

    const tipo =
        tipoElemento.value;

    const pagamento =
        pagamentoElemento.value;


    // Verifica o nome

    if (nome === "") {

        alert(
            "Digite seu nome antes de finalizar."
        );

        nomeElemento.focus();

        return;
    }


    // Verifica endereço somente no delivery

    if (
        tipo === "delivery" &&
        endereco === ""
    ) {

        alert(
            "Digite seu endereço para a entrega."
        );

        enderecoElemento.focus();

        return;
    }


    // ======================================
    // MONTA A MENSAGEM
    // ======================================

    let mensagem =
        "🔥 *NOVO PEDIDO - BRASA BURGER*%0A%0A";


    mensagem +=
        "*Cliente:* " +
        encodeURIComponent(nome) +
        "%0A";


    // DELIVERY

    if (tipo === "delivery") {

        mensagem +=
            "*Tipo:* 🛵 Delivery%0A";

        mensagem +=
            "*Endereço:* " +
            encodeURIComponent(endereco) +
            "%0A";

    }


    // RETIRADA

    else {

        mensagem +=
            "*Tipo:* 🏪 Retirada no local%0A";

    }


    mensagem +=
        "*Pagamento:* " +
        encodeURIComponent(pagamento) +
        "%0A%0A";


    mensagem +=
        "🍔 *PEDIDO:*%0A";


    // ======================================
    // PRODUTOS
    // ======================================

    let total = 0;


    carrinho.forEach(function(item) {

        const subtotal =
            item.preco * item.quantidade;


        total += subtotal;


        mensagem +=
            item.quantidade +
            "x " +
            encodeURIComponent(item.nome) +
            " - R$ " +
            subtotal
                .toFixed(2)
                .replace(".", ",") +
            "%0A";

    });


    // ======================================
    // TOTAL
    // ======================================

    mensagem +=
        "%0A💰 *TOTAL: R$ " +
        total
            .toFixed(2)
            .replace(".", ",") +
        "*";


    // ======================================
    // WHATSAPP
    // ======================================

    // Número da Brasa Burger
    // Coloque o número real depois.

    const numeroWhatsApp =
        "5581999999999";


    const url =
        "https://wa.me/" +
        numeroWhatsApp +
        "?text=" +
        mensagem;


    window.open(
        url,
        "_blank"
    );
}


// ==========================================
// INICIALIZAÇÃO
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        atualizarCarrinho();

        alterarTipoPedido();

    }
);